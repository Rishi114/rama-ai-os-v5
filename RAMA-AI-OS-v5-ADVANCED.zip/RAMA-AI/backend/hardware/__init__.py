# RAMA hardware module
