# RAMA graph module
