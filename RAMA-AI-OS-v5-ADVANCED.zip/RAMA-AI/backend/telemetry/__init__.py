# RAMA telemetry module
