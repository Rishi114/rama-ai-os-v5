# RAMA vision module
